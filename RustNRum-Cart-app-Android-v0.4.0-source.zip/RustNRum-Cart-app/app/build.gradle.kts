plugins { id("com.android.application") }
android { namespace = "com.rustnrum.cart"; compileSdk = 35; defaultConfig { applicationId = "com.rustnrum.cart"; minSdk = 26; targetSdk = 35 } }
